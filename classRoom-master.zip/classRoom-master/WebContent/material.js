$(document).ready(function(e){
/*$(".file").on('click',function(e){
e.preventDefault();



id = e.target.id;

$.ajax({

	type: "GET",
	url: "Download?id="+id,
	success: function(data){

	}
});

});*/
});