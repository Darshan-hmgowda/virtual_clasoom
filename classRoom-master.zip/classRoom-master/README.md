# classRoom
Virtual classroom

This is a virtual classroom web application which provides communication and resource sharing between students and teachers.

Technology used:

Frontend: bootstrap3,html,css,jquery,javascript

Backend: java servlets and jsp

Database: mysql

1) You can directly import this project into eclipse.
2) You have to add mysql connector jar file and servlet-api jar file to build path for the project to work. 
3) The jars are given as jars.zip.If they fail to work download latest jars and 
add them.
4) You can contact me if any asistance is needed.
5) Improvements for the project are welcome.
